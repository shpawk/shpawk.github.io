#!/usr/bin/env python3
import requests
import json
import os

API_KEY = "800235a573ba473a9ae163835250407"

# Load condition codes from JSON (downloaded once)
try:
    with open(os.path.expanduser("~/.config/waybar/scripts/conditions.json")) as f:
        conditions_data = json.load(f)
except:
    conditions_data = []


def get_icon(condition_code, is_day):
    for item in conditions_data:
        if item["code"] == condition_code:
            text = item["day"] if is_day else item["night"]
            if "thunder" in text.lower():
                return "⛈️"
            elif "snow" in text.lower():
                return "❄️"
            elif "rain" in text.lower():
                return "🌧️"
            elif "cloud" in text.lower():
                return "☁️" if "overcast" in text.lower() else "⛅"
            elif "sun" in text.lower() or "clear" in text.lower():
                return "☀️" if is_day else "🌙"
            elif "mist" in text.lower() or "fog" in text.lower():
                return "🌫️"
            else:
                return "🌡️"
    return "🌡️"


try:
    loc_data = requests.get("https://ipinfo.io", timeout=5).json()
    city = loc_data.get("city")
    if not city:
        raise ValueError("City not found in IP info")

    url = f"http://api.weatherapi.com/v1/current.json?key={API_KEY}&q={city}&aqi=no"
    weather = requests.get(url, timeout=5).json()

    temp = weather["current"]["temp_f"]
    condition = weather["current"]["condition"]["text"]
    code = weather["current"]["condition"]["code"]
    is_day = weather["current"]["is_day"] == 1

    icon = get_icon(code, is_day)
    print(f"{icon} {temp}°F {condition}")

except Exception as e:
    print(f"Weather: N/A ({e})")
