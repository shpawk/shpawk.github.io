#!/bin/bash

CONFIG_DIR="$HOME/.config/waybar"
SCRIPTS_DIR="$CONFIG_DIR/scripts"
WEATHER_SCRIPT="$SCRIPTS_DIR/weather-app.py"
CONDITIONS_JSON="$SCRIPTS_DIR/conditions.json"
WAYBAR_CONFIG="$CONFIG_DIR/config"

API_KEY="800235a573ba473a9ae163835250407"

echo "Creating scripts directory..."
mkdir -p "$SCRIPTS_DIR"

echo "Copying weather-app.py and conditions.json..."
cp weather-app.py "$WEATHER_SCRIPT"
cp conditions.json "$CONDITIONS_JSON"

chmod +x "$WEATHER_SCRIPT"

echo "Backing up your current Waybar config..."
cp "$WAYBAR_CONFIG" "$WAYBAR_CONFIG.bak"

echo "Adding weather module to Waybar config..."

if ! grep -q '"custom/weather"' "$WAYBAR_CONFIG"; then
  sed -i '/"modules-right": \[/ s/\]/  "custom\/weather",\n]/' "$WAYBAR_CONFIG"

  if ! grep -q '"custom/weather":' "$WAYBAR_CONFIG"; then
    sed -i '/"custom": {/a\
    "custom/weather": {\
      "exec": "'"$WEATHER_SCRIPT"'",\
      "interval": 900,\
      "tooltip": false\
    },' "$WAYBAR_CONFIG"
  fi
fi

echo "Done! Restart Waybar with: pkill waybar && waybar &"
