# Weather Widget for Waybar

A simple dynamic weather widget for [Waybar](https://github.com/Alexays/Waybar) using [WeatherAPI](https://www.weatherapi.com/) with automatic location detection and icon support.

---

## Features

- Displays current temperature in **Fahrenheit** (configurable)
- Shows weather condition icon based on full WeatherAPI condition codes
- Automatically detects your location via IP
- Easy integration with Waybar as a custom module

---

## Requirements

- Python 3
- Python package: `requests` (install with `pip install requests`)
- Waybar

---

## Installation

1. **Clone or download this repository**

```bash
git clone https://github.com/yourusername/weather-widget.git
cd weather-widget
